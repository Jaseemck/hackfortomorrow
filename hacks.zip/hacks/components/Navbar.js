import Link from 'next/link';
import {Menu,Container, Segment} from 'semantic-ui-react';



const Navbar = () => (

            <Menu fixed='top'>
      <Container>
        <Menu.Item as='a' header>
          EthRelief
        </Menu.Item>
<Menu.Item><Link href="/"><a>Home</a></Link></Menu.Item>
<Menu.Item><Link href="/about"><a>About</a></Link></Menu.Item>
<Menu.Item><Link href="/form"><a>Create New</a></Link></Menu.Item>
</Container>
</Menu>


);

export default Navbar;