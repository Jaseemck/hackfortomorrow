import Head from 'next/head';
import Navbar from './Navbar';

const Layout = (props) => (
    <div>
    <Head>
        <title>AwesomeApp</title>
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.css"></link>
        </Head>
    <Navbar/>
    <span></span>
    <style jsx>{`
  span{
      display:flex;
    margin:50px;
  }
  `}
  </style>
    {props.children}    
     </div>
);

export default Layout;

