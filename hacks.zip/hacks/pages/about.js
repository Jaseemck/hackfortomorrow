import Layout from '../components/Layout';

const About = () => (
<Layout>
<div>
    
    <h1>
        This is the about page of the app
    </h1>
    <p>This is the application to view bitcoin prices</p>
</div>
</Layout>
);

export default About;